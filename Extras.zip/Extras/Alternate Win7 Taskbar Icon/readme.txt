ALT WINDOWS TASKBAR ICON
------------------------
This replaces the Windows 7 taskbar icon with the Mac OSX dock icon.

To install, just extract to your TF2 folder over the top of FrankenHUD and double check to make sure that resource/game.ico is set to Read-Only.