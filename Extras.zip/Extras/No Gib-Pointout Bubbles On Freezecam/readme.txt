NO FREEZE PANEL CALLOUTS
------------------------
This addon removes the "Your Head!" "More bits!" etc. bubbles from the Freeze Cam.

To install, just extract to your TF2 folder over the top of FrankenHUD.