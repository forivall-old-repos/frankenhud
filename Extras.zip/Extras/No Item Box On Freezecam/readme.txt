NO ITEM BOX ON FREEZECAM
------------------------
This addon removes the item box when killed by an enemy with a non-stock weapon.

To install, just extract to your TF2 folder over the top of FrankenHUD.