CLASSIC DEATH NOTICES
------------------------------------------
This addon restores the default obituary behavior, instead of the m0re-style ones added by default.

To install, just extract to your TF2 folder over the top of FrankenHUD.