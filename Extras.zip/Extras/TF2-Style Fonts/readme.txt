TF2-STYLE FONTS
---------------
This addon restyles the fonts used for chat and text to look more like the TF2 fonts instead of the OS defaults.

To install, just extract to your TF2 folder over the top of FrankenHUD.