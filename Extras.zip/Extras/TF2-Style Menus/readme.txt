TF2-STYLE MENUS
---------------
This addon reskinned the Source engine windows (Console, Options menu etc.) to better fit with TF2.

To install, just extract to your TF2 folder. FrankenHUD is not required!